//
//  ContentView.swift
//  TextFieldSample
//
//  Created by Taeyoun Lee on 2022/07/11.
//

import SwiftUI

struct ContentView: View {
    
    // https://www.youtube.com/watch?v=9OC8e0OULBg
    // How to use @FocusState in SwiftUI
    //@FocusState private var userNameIsFocus: Bool
    @State private var userName: String = ""
    @State private var contentsHeight: CGFloat = 55
    
    var body: some View {
        VStack {
            GeometryReader { proxy in
                ScrollView(.vertical) {
                    VStack {
                        if proxy.size.height > contentsHeight {
                            Spacer()
                                .frame(height: (proxy.size.height - contentsHeight)/2)
                        }
                        
                        TextField("Add your name ...", text: $userName)
                            .padding(.leading)
                            .frame(height: contentsHeight)
                            .frame(maxWidth: .infinity)
                            .background(Color.gray.brightness(0.3))
                            .cornerRadius(10)
                        
                        if proxy.size.height > contentsHeight {
                            Spacer()
                                .frame(height: (proxy.size.height - contentsHeight)/2)
                        }
                    }
                }
            }
            
            Button {
                hideKeyboard()
            } label: {
                Text("Submit")
            }
        }
        .padding(40)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

#if canImport(UIKit)
extension View {
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
#endif
