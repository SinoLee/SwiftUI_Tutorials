//
//  TextFieldSampleApp.swift
//  TextFieldSample
//
//  Created by Taeyoun Lee on 2022/07/11.
//

import SwiftUI

@main
struct TextFieldSampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
